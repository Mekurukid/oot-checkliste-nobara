"""Nobara desktop integration, without Python GUI dependencies or shell eval."""
from __future__ import annotations
import contextlib
import datetime
import html
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time

EDITION='Nobara Edition 2.7'
RUNTIME_FILES=(
    'app.py','launcher.py','desktop_support.py','guide_reader.py','catalog.json',
    'index.html','style.css','ui.js','nobara-ui.js','icon.svg','placeholder.svg',
    'STARTEN.sh','INSTALLIEREN.sh','NOBARA-INSTALLIEREN.sh','DIAGNOSE.sh',
    'STOPPEN.sh','LIESMICH.txt','LIZENZ.txt','QUELLEN.txt','DIREKTSTART.html',
)

def xdg_dir(key: str, fallback: str) -> Path:
    value=os.environ.get(key,'')
    return Path(value) if value and Path(value).is_absolute() else Path.home()/fallback

def install_target() -> Path:
    # Same program/data identity as v1/v2. No divergent save directory.
    return xdg_dir('XDG_DATA_HOME','.local/share')/'oot-herzteil-checkliste-programm'

def log_directory() -> Path:
    return xdg_dir('XDG_STATE_HOME','.local/state')/'oot-checklisten'

def os_release(path: Path=Path('/etc/os-release')) -> dict:
    result={}
    try:
        for line in path.read_text(encoding='utf-8').splitlines():
            if '=' not in line or line.startswith('#'):continue
            key,value=line.split('=',1)
            if re.fullmatch(r'[A-Z_]+',key):result[key]=value.strip().strip('\"\'')[:200]
    except OSError:pass
    return result

def system_summary() -> dict:
    release=os_release()
    return dict(edition=EDITION,system=release.get('PRETTY_NAME','Linux'),
                nobara=release.get('ID','').lower()=='nobara',
                desktop=os.environ.get('XDG_CURRENT_DESKTOP','nicht erkannt')[:100],
                session=os.environ.get('XDG_SESSION_TYPE') or ('Wayland' if os.environ.get('WAYLAND_DISPLAY') else 'nicht erkannt'),
                python=platform.python_version(),architecture=platform.machine())

def graphical() -> bool:
    return bool(os.environ.get('WAYLAND_DISPLAY') or os.environ.get('DISPLAY'))

def desktop_environment() -> dict:
    # Keep session bus + activation token, but not a virtualenv's library paths.
    env=os.environ.copy()
    for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','LD_LIBRARY_PATH','LD_PRELOAD'):
        env.pop(key,None)
    return env

def _command_ok(command: list, timeout: float=4.0) -> bool:
    """True means a URL-open request was accepted, not that a window was seen."""
    try:
        child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL,env=desktop_environment(),
                               start_new_session=True,close_fds=True)
        try:return child.wait(timeout=timeout)==0
        except subprocess.TimeoutExpired:return True
    except OSError:return False

def open_browser(url: str) -> bool:
    if not re.fullmatch(r'http://127\.0\.0\.1:\d+/[a-f0-9]{48}/',url):
        raise ValueError('Es darf nur die lokale Checklisten-Adresse geoeffnet werden.')
    if not graphical():return False
    # Desktop handlers retain the user's default, including Flatpak browsers.
    is_gnome='GNOME' in os.environ.get('XDG_CURRENT_DESKTOP','').upper()
    handlers=[('gio',['open',url]),('xdg-open',[url])] if is_gnome else [('xdg-open',[url]),('gio',['open',url])]
    handlers.extend([('kde-open6',[url]),('kde-open',[url])])
    for name,args in handlers:
        binary=shutil.which(name)
        if binary and _command_ok([binary]+args):
            print('Browser-Anfrage ueber '+name+' uebergeben.');return True
    for name in ('firefox','librewolf','chromium','chromium-browser','google-chrome-stable','google-chrome','brave-browser'):
        binary=shutil.which(name)
        if binary and _command_ok([binary,url]):
            print('Browser-Anfrage an '+name+' uebergeben.');return True
    flatpak=shutil.which('flatpak')
    if flatpak:
        for app_id in ('org.mozilla.firefox','io.gitlab.librewolf-community','org.chromium.Chromium','com.google.Chrome','com.brave.Browser'):
            try:
                result=subprocess.run([flatpak,'info',app_id],stdin=subprocess.DEVNULL,
                                      stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                                      timeout=4,env=desktop_environment())
                if result.returncode==0 and _command_ok([flatpak,'run',app_id,url]):
                    print('Browser-Anfrage an Flatpak '+app_id+' uebergeben.');return True
            except (OSError,subprocess.TimeoutExpired):continue
    return False

def dialog(title: str, message: str, error: bool=False, report: Path | None=None) -> bool:
    if not graphical():return False
    candidates=[]
    kdialog=shutil.which('kdialog')
    zenity=shutil.which('zenity')
    if kdialog:
        if report:candidates.append([kdialog,'--title',title,'--textbox',str(report),'840','570'])
        else:candidates.append([kdialog,'--title',title,'--error' if error else '--msgbox',html.escape(message).replace('\n','<br>')])
    if zenity:
        if report:candidates.append([zenity,'--text-info','--title='+title,'--filename='+str(report),'--width=840','--height=570'])
        else:candidates.append([zenity,'--error' if error else '--info','--title='+title,'--text='+html.escape(message),'--width=620'])
    for command in candidates:
        try:
            subprocess.run(command,env=desktop_environment(),stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=180)
            return True
        except (OSError,subprocess.TimeoutExpired):continue
    # No GUI toolkit installed: show the existing report in a terminal.
    if report:
        script='cat -- "$1"; printf "\\nEnter zum Schliessen. "; IFS= read -r answer'
        for name,flag in (('konsole','-e'),('gnome-terminal','--'),('xterm','-e')):
            binary=shutil.which(name)
            if binary and _command_ok([binary,flag,'/bin/sh','-c',script,'oot-report',str(report)]):return True
    notify=shutil.which('notify-send')
    if notify:return _command_ok([notify,title,message[:1500]])
    return False

def redact(text: str) -> str:
    text=re.sub(r'http://127\.0\.0\.1:\d+/[a-f0-9]{48}/','http://127.0.0.1:PORT/[SITZUNG]/',text)
    text=re.sub(r'\b[a-f0-9]{48}\b','[SITZUNG]',text)
    # Reports are shareable but still let the user inspect before sending.
    home=str(Path.home())
    if len(home)>1:text=text.replace(home,'~')
    return text

def diagnostic_text(app, directory: Path) -> tuple:
    info=system_summary();lines=['OOT NOBARA STARTDIAGNOSE','========================',
        'App-Version: '+app.VERSION,'Edition: '+EDITION,
        'System: '+info['system'],'Desktop: '+info['desktop'],'Sitzung: '+info['session'],
        'Architektur: '+info['architecture'],'Python: '+info['python'],
        'Python-Datei: '+sys.executable,'Programmordner: '+str(app.ROOT),
        'Datenordner: '+str(directory),'','Programmdateien:']
    ok=True
    for name in RUNTIME_FILES:
        exists=(app.ROOT/name).is_file();ok=ok and exists
        lines.append('  '+name+': '+('OK' if exists else 'FEHLT'))
    try:
        directory.mkdir(parents=True,exist_ok=True)
        fd,path=tempfile.mkstemp(prefix='.nobara-test-',dir=str(directory));os.close(fd);os.unlink(path)
        lines.append('Schreibtest: OK')
    except OSError as exc:ok=False;lines.append('Schreibtest: FEHLER - '+str(exc))
    try:
        with socket.socket() as sock:sock.bind(('127.0.0.1',0))
        lines.append('Lokaler Port: OK (nur 127.0.0.1)')
    except OSError as exc:ok=False;lines.append('Lokaler Port: FEHLER - '+str(exc))
    try:
        import ssl
        ssl.create_default_context()
        lines.append('HTTPS-Zertifikate: OK')
    except Exception as exc:lines.append('HTTPS-Zertifikate: FEHLER - '+str(exc))
    lines.append('Grafische Sitzung: '+('ja' if graphical() else 'nicht erkannt'))
    for name in ('xdg-open','gio','kde-open6','kdialog','zenity','flatpak','firefox','chromium'):
        lines.append(name+': '+('gefunden' if shutil.which(name) else 'nicht gefunden (optional)'))
    live=app.running(directory)
    lines.append('Laufende Version: '+(live[1] if live else 'keine'))
    lines.append('Serverprotokoll: '+str(directory/'programm-v2.log'))
    lines.extend(['','Es wurden keine Spielstaende, Notizen, Browserprofile oder Sitzungstoken ausgegeben.',
        'Diese Diagnose fuehrt keinen Internetabruf aus und sendet keine Daten.',
        'Vor dem Weitergeben bitte trotzdem pruefen.','',
        'Falls Python oder der Desktop-Oeffner fehlt, auf Nobara im Terminal:',
        '  sudo dnf install python3 xdg-utils',
        'Nur fehlende Pakete installieren; die App selbst OHNE sudo starten.',
        'Keine Aenderung an AppArmor, Firewall, Grafiktreibern oder Wayland noetig.'])
    return redact('\n'.join(lines)+'\n'),ok

def install_app(app) -> int:
    directory=app.data_folder()
    if app.running(directory):
        print('Bitte die laufende App unter "Sichern & verwalten > App beenden" beenden und erneut installieren.')
        print('Alternativ nach dem Speichern: sh NOBARA-INSTALLIEREN.sh --restart')
        return 2
    base=xdg_dir('XDG_DATA_HOME','.local/share');target=install_target()
    if target.is_symlink():raise OSError('Der Programmordner ist ein symbolischer Link. Bitte einen normalen Ordner verwenden.')
    if app.ROOT.resolve()==target.resolve():
        print('Diese Kopie ist bereits im Benutzerkonto installiert. Bitte zum Update die neue Datei verwenden.')
        return 0
    missing=[name for name in RUNTIME_FILES if not(app.ROOT/name).is_file()]
    if missing:raise OSError('Dateien fehlen: '+', '.join(missing)+'. Bitte das ganze Archiv entpacken.')
    base.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.oot-neu-',dir=str(base)))
    previous=base/('.oot-vor-nobara-'+str(time.time_ns()))
    launcher=base/'applications'/'oot-herzteil-checkliste.desktop'
    old_desktop=launcher.read_bytes() if launcher.is_file() else None
    moved=False;placed=False
    try:
        for name in RUNTIME_FILES:
            shutil.copyfile(app.ROOT/name,stage/name)
            (stage/name).chmod(0o755 if name.endswith('.sh') else 0o644)
        for name in ('app.py','launcher.py','desktop_support.py','guide_reader.py'):
            compile((stage/name).read_text(encoding='utf-8'),name,'exec')
        if directory.is_dir():
            for name in ('fortschritt-v2.json','fortschritt.json'):
                state=directory/name
                if state.is_file():
                    backup=directory/(name[:-5]+'-vor-nobara-'+str(time.time_ns())+'.json')
                    app.atomic_bytes(backup,state.read_bytes())
        if target.exists():os.replace(target,previous);moved=True
        os.replace(stage,target);placed=True
        command=app.desktop_value(app.desktop_arg('/bin/sh')+' '+app.desktop_arg(str(target/'STARTEN.sh')))
        content=('[Desktop Entry]\nType=Application\nVersion=1.0\nName=OoT Sammel-Checklisten\n'
            'Comment=Ocarina of Time - Nobara Edition mit zehn Checklisten\n'
            'Exec='+command+' --desktop\n'
            'Icon='+app.desktop_value(str(target/'icon.svg'))+'\n'
            'Terminal=false\nCategories=Game;\nStartupNotify=false\n'
            'Keywords=Zelda;Ocarina;Checkliste;Nobara;Skulltula;\nActions=Diagnose;\n\n'
            '[Desktop Action Diagnose]\nName=Startdiagnose anzeigen\n'
            'Exec='+command+' --desktop --diagnose\n')
        app.atomic_bytes(launcher,content.encode('utf-8'));launcher.chmod(0o644)
    except Exception:
        if placed and target.is_dir():shutil.rmtree(target)
        if moved and previous.is_dir():os.replace(previous,target)
        if old_desktop is not None:app.atomic_bytes(launcher,old_desktop)
        elif launcher.exists():launcher.unlink()
        raise
    finally:
        if stage.exists():shutil.rmtree(stage)
    # Keep previous program files for manual recovery; never delete save data.
    for executable,args in (('update-desktop-database',[str(launcher.parent)]),('kbuildsycoca6',['--noincremental'])):
        binary=shutil.which(executable)
        if binary:
            try:subprocess.run([binary]+args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15,env=desktop_environment())
            except (OSError,subprocess.TimeoutExpired):pass
    print('Installiert: OoT Sammel-Checklisten - '+EDITION)
    print('Programmordner:',target)
    print('App-Menue: OoT Sammel-Checklisten')
    print('Deine bisherigen Haekchen, Notizen und Bilddateien bleiben im bisherigen Datenordner.')
    print('DIREKTSTART.html nutzt einen getrennten Browser-Spielstand: dort eine JSON-Sicherung exportieren und hier importieren.')
    return 0
