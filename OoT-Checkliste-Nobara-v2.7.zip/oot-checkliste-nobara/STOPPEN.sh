#!/bin/sh
set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
printf '%s\n' 'Offene Notizen vorher speichern. Der gespeicherte Fortschritt wird nicht geloescht.'
exec /bin/sh "$HERE/STARTEN.sh" --stop "$@"
