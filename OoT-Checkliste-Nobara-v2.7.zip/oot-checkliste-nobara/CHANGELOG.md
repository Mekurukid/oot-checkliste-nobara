# Changelog

## 2.7.0 – 2026-09-14

- Kategorie **Ausrüstung & Upgrades** vollständig überarbeitet.
- 23/23 Einträge mit genaueren Fundorten, Voraussetzungen und verständlicheren Schritten.
- Bestehende 2.6-Daten und Fortschritte bleiben kompatibel.
- Versionsangaben in der Oberfläche vereinheitlicht.

## 2.6.0 – 2026-09-14

- Herzteile, Skulltulas, Tauschgeschäft, Masken, Nachtschwärmer, Wundererbsen und Flaschen anhand ausführlicher Guides präzisiert.
- Genauere Voraussetzungen wie Alter, Item, Lied, Tageszeit und Quest-Fortschritt.

## 2.5.0

- Strukturierte Voraussetzungen für alle 224 Einträge.
- Verbesserte verständliche Beschreibungen.

## 2.4.1

- Fehler `required is not defined` behoben.

## 2.4.0

- Neues Feld **Benötigt** für alle Sammelobjekte.

## 2.3.0

- Offline-Beschreibungen für alle 224 Einträge.

## 2.2.0

- Nobara-optimierter Starter, Installer, Desktop-Integration und Diagnose.

## 2.0.0

- Erweiterung auf zehn Checklistenbereiche.
