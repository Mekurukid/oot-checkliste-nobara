'use strict';
/* All guide text and notes are inserted as text, never as HTML. No dependencies. */
const $ = id => document.getElementById(id);
const mk = (tag, cls, text) => {const n = document.createElement(tag); if(cls) n.className=cls; if(text!==undefined) n.textContent=text; return n;};
const iconPaths = {
 heart:'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z',
 skull:'M8 21v-4H5a9 9 0 1 1 14 0h-3v4H8M10 17v4m4-4v4M8 10h1m6 0h1m-4 3v1',
 sword:'m4 20 4-4M3 16l5 5m-2-7 4 4m-2-5L18 3l3 0v3L11 16',
 mask:'M3 5c6 3 12 3 18 0v7c0 5-5 9-9 9s-9-4-9-9V5m3 5 3 1m6 0 3-1m-9 6h6',
 ghost:'M5 21V10a7 7 0 0 1 14 0v11l-4-3-3 3-3-3-4 3m4-12v2m6-2v2',
 fairy:'M12 11C2-1-2 13 10 14m2-3C22-1 26 13 14 14m-3 1c-9-2-7 8 0 2m2-2c9-2 7 8 0 2M12 10v9m-1-6h2',
 leaf:'M20 3C5 1-2 15 7 20c8 4 14-3 13-17ZM4 22l12-14',
 bottle:'M9 3h6m-5 0v6l-4 5v6c0 1 1 2 2 2h8c1 0 2-1 2-2v-6l-4-5V3M6 15h12',
 music:'M9 18V5l11-2v12M9 8l11-2M9 18a3 3 0 1 1-3-3c2 0 3 1 3 3Zm11-3a3 3 0 1 1-3-3c2 0 3 1 3 3Z',
 shield:'M12 2 3 6v6c0 6 9 10 9 10s9-4 9-10V6L12 2Zm0 4v12',
 all:'M3 3h7v7H3V3m11 0h7v7h-7V3M3 14h7v7H3v-7m11 0h7v7h-7v-7',
 photo:'M3 4h18v16H3V4m0 12 6-6 8 10m-3-5 3-3 4 4M15 8h1'
};
function icon(name) {
 const s=document.createElementNS('http://www.w3.org/2000/svg','svg');
 for(const [k,v] of Object.entries({viewBox:'0 0 24 24',fill:'none',stroke:'currentColor','stroke-width':'1.5','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true'}))s.setAttribute(k,v);
 const p=document.createElementNS(s.namespaceURI,'path');p.setAttribute('d',iconPaths[name]||iconPaths.heart);s.append(p);return s;
}
let guide=null, state={checked:[],notes:{},updated:''}, checked=new Set(), active='herzen', statusFilter='all';
let cards=new Map(),navs=new Map(),byId=new Map(),cats=new Map(),queue=[],saving=false,saveFailure='',busy=false,closed=false;
let generation=0,notesTimers=new Map(),toastTimer=null,undoAction=null,pollTimer=null,stateTimer=null,pollBusy=false,lastRevision=-1,media=null;
let galleryItem=null,galleryIndex=0;
const fold=s=>String(s||'').toLocaleLowerCase('de').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
async function api(path,data){
 const control=new AbortController(), timeout=setTimeout(()=>control.abort(),15000);
 try{
  const options={signal:control.signal,cache:'no-store'};
  if(data!==undefined){options.method='POST';options.headers={'Content-Type':'application/json'};options.body=JSON.stringify(data);}
  const res=await fetch('api/'+path,options);let body;
  try{body=await res.json();}catch{throw new Error('Die App antwortet nicht korrekt. Bitte mit STARTEN.sh neu starten.');}
  if(!res.ok)throw new Error(body.error||'Die Aktion konnte nicht ausgef\u00fchrt werden.');return body;
 }catch(e){
  if(e.name==='AbortError')throw new Error('Die App antwortet nicht. Bitte STARTEN.sh ausf\u00fchren.');
  if(e instanceof TypeError)throw new Error('Keine Verbindung zur lokalen App. Bitte STARTEN.sh ausf\u00fchren.');throw e;
 }finally{clearTimeout(timeout);}
}
function tell(text,undo=null){clearTimeout(toastTimer);$('toast-text').textContent=text;undoAction=undo;$('toast-undo').hidden=!undo;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,undo?6500:5000);}
function confirmAction(title,message,button='Best\u00e4tigen'){
 const d=$('confirm-dialog');$('confirm-title').textContent=title;$('confirm-message').textContent=message;$('confirm-ok').textContent=button;
 return new Promise(resolve=>{
  let finished=false;
  const finish=value=>{if(finished)return;finished=true;d.close();$('confirm-ok').onclick=null;$('confirm-cancel').onclick=null;d.oncancel=null;resolve(value);};
  $('confirm-ok').onclick=()=>finish(true);$('confirm-cancel').onclick=()=>finish(false);d.oncancel=e=>{e.preventDefault();finish(false);};d.showModal();$('confirm-cancel').focus();
 });
}
function applyState(next){state=next;checked=new Set(next.checked);for(const [id,c] of cards){c.check.checked=checked.has(id);c.node.classList.toggle('done',checked.has(id));c.mark.textContent=checked.has(id)?cats.get(c.item.category).verb:'Noch offen';if(document.activeElement!==c.note)c.note.value=state.notes[id]||'';c.notes.classList.toggle('has-note',Boolean(state.notes[id]));}renderCounters();filterCards();}
function saveIndicator(){
 const pending=saving||queue.length||notesTimers.size;
 $('save-label').textContent=closed?'App beendet':saveFailure?'Noch nicht gespeichert':pending?'Wird gespeichert ...':'Fortschritt gespeichert';
 $('save-indicator').classList.toggle('pending',Boolean(pending));$('save-indicator').classList.toggle('failed',Boolean(saveFailure));
 $('storage-error').hidden=!saveFailure;$('storage-error-text').textContent=saveFailure+' Deine \u00c4nderungen bleiben in diesem Fenster. Erneut speichern oder eine Sicherung exportieren.';
}
function enqueue(op,data){queue.push({op,data});saveFailure='';saveIndicator();drain();}
async function drain(){
 if(saving||closed||saveFailure)return;saving=true;saveIndicator();
 try{while(queue.length){const job=queue[0];const response=await api(job.op,job.data);queue.shift();state.updated=response.state.updated;if(!queue.length&&!notesTimers.size)applyState(response.state);}}
 catch(e){saveFailure=e.message;}
 finally{saving=false;saveIndicator();}
}
function flushNotes(){for(const [id,t] of notesTimers){clearTimeout(t);queue.push({op:'note',data:{id,note:state.notes[id]||''}});}notesTimers.clear();saveFailure='';drain();}
async function waitSaved(){flushNotes();const start=Date.now();while(saving||queue.length){if(saveFailure)throw new Error(saveFailure);if(Date.now()-start>22000)throw new Error('Speichern dauert zu lange. Bitte eine Sicherung exportieren.');await new Promise(r=>setTimeout(r,60));}}
function toggle(id,value){
 if(closed||busy)return;generation++;if(value)checked.add(id);else checked.delete(id);state.checked=[...checked].sort();
 const c=cards.get(id);c.check.checked=value;c.node.classList.toggle('done',value);c.mark.textContent=value?cats.get(c.item.category).verb:'Noch offen';
 c.node.classList.remove('just-found');if(value){void c.node.offsetWidth;c.node.classList.add('just-found');}
 renderCounters();filterCards();enqueue('check',{id,checked:value});tell(value?'Abgehakt. Weiter geht dein Abenteuer!':'Wieder als offen markiert.',()=>toggle(id,!value));
}
function pictureTo(img,picture,onResult){
 img.onload=null;img.onerror=null;img.removeAttribute('src');img.hidden=true;
 if(!picture){onResult(false);return;}
 img.alt='Fundort-Bild von Zelda Chronicles';let triedRemote=false;
 img.onload=()=>{img.hidden=false;onResult(true);};
 img.onerror=()=>{
  if(picture.cached&&guide.network&&!triedRemote){triedRemote=true;img.src=picture.url;return;}
  img.hidden=true;onResult(false);
 };
 if(picture.cached){img.hidden=false;img.src='image/'+picture.key;}
 else if(guide.network){triedRemote=true;img.hidden=false;img.src=picture.url;}
 else onResult(false);
}
function refreshPicture(c,force=false){
 const p=c.item.pictures[0],signature=c.item.pictures.map(p=>p.key+':'+p.cached).join(',')+':'+guide.network;
 if(!force&&c.signature===signature)return;c.signature=signature;
 c.placeholder.hidden=false;c.placeholderMessage.textContent=guide.network?'Bild wird geladen ...':'Noch nicht offline gespeichert';
 pictureTo(c.photo,p,ok=>{c.placeholder.hidden=ok;if(!ok)c.placeholderMessage.textContent=guide.network?'Bild noch nicht verf\u00fcgbar':'Noch nicht offline gespeichert';});
 c.caption.textContent=(p&&p.cached?'Lokal gespeichert':'Originalbild verkn\u00fcpft')+' \u00b7 '+c.item.pictures.length+(c.item.pictures.length===1?' Bild':' Bilder');
 c.thumbs.replaceChildren();
 if(c.item.pictures.length>1){c.item.pictures.slice(0,7).forEach((p,j)=>{const b=mk('button','thumb-button',String(j+1));b.type='button';b.title='Bild '+(j+1)+' \u00f6ffnen';b.setAttribute('aria-label',b.title);b.onclick=()=>openGallery(c.item.id,j);c.thumbs.append(b);});
  if(c.item.pictures.length>7){const b=mk('button','thumb-button','+'+(c.item.pictures.length-7));b.title='Weitere Bilder';b.onclick=()=>openGallery(c.item.id,7);c.thumbs.append(b);}}
}
function makeCard(item){
 const node=mk('article','entry');node.id='entry-'+item.id.replace(':','-');node.dataset.id=item.id;
 const inner=mk('div','entry-inner'), label=mk('label','check-wrap'),check=mk('input');check.type='checkbox';check.setAttribute('aria-label',item.title+' abhaken');label.append(check);
 const copy=mk('div','copy'),top=mk('div','entry-topline');top.append(mk('span','entry-number',String(item.number).padStart(item.category==='skulltula'?3:2,'0')),mk('span','entry-category',cats.get(item.category).title),mk('span','age-badge',item.age.replace(' | ',' + ')));
 const title=mk('h3','',item.title),context=mk('p','entry-context',item.region+(item.local_number?' \u00b7 Fundort '+item.local_number+' im Gebiet':'')),required=mk('p','required'),desc=mk('p','description'),hint=mk('p','hint');copy.append(top,title,context,required,desc,hint);
 const photoArea=mk('div','photo-area'),photoButton=mk('button','photo-button');photoButton.type='button';photoButton.setAttribute('aria-label','Bilder zu '+item.title+' vergr\u00f6\u00dfern');
 const photo=mk('img');photo.loading='lazy';photo.decoding='async';photo.referrerPolicy='no-referrer';
 const placeholder=mk('span','photo-placeholder'),placeholderMessage=mk('span','','Bild wird geladen ...');placeholder.append(icon('photo'),placeholderMessage,mk('small','','Bilder & Texte laden'));
 const zoom=mk('span','zoom','\u2922');zoom.setAttribute('aria-hidden','true');photoButton.append(photo,placeholder,zoom);photoButton.onclick=()=>openGallery(item.id,0);
 const caption=mk('div','photo-caption'),thumbs=mk('div','thumbnail-row');photoArea.append(photoButton,caption,thumbs);inner.append(label,copy,photoArea);
 const bottom=mk('div','entry-bottom'),mark=mk('span','entry-status','Noch offen'),notes=mk('details','notes'),summary=mk('summary','','Eigene Notiz'),note=mk('textarea');
 note.rows=2;note.maxLength=2000;note.placeholder='Was m\u00f6chtest du dir merken?';note.setAttribute('aria-label','Notiz zu '+item.title);notes.append(summary,note);bottom.append(mark,notes);node.append(inner,bottom);
 const c={node,item,check,desc,hint,title,context,required,photo,placeholder,placeholderMessage,caption,thumbs,mark,notes,note,signature:''};
 check.onchange=()=>toggle(item.id,check.checked);
 node.addEventListener('click',e=>{if(e.target.closest('button,a,input,textarea,select,details,label')||String(window.getSelection()))return;toggle(item.id,!checked.has(item.id));});
 note.addEventListener('input',()=>{generation++;state.notes[item.id]=note.value;notes.classList.toggle('has-note',Boolean(note.value));if(notesTimers.has(item.id))clearTimeout(notesTimers.get(item.id));notesTimers.set(item.id,setTimeout(()=>{notesTimers.delete(item.id);enqueue('note',{id:item.id,note:state.notes[item.id]||''});},400));saveIndicator();});
 updateCardText(c);refreshPicture(c);return c;
}
function formatRequirements(item){
 const r=item.requirements||{};const lines=['Voraussetzungen'];
 if(r.age)lines.push('Alter: '+r.age);
 if(r.items&&r.items.length)lines.push('Benötigt: '+r.items.join(' · '));
 else lines.push('Benötigt: keine besonderen Items');
 if(r.conditions&&r.conditions.length)lines.push('Bedingung: '+r.conditions.join(' · '));
 if(r.recommended&&r.recommended.length)lines.push('Tipp: '+r.recommended.join(' · '));
 return lines.join('\n');
}
function updateCardText(c){c.required.textContent=formatRequirements(c.item);c.desc.textContent=c.item.description||c.item.hint;c.desc.classList.toggle('pending',!c.item.description);c.hint.textContent=c.item.description?'':'Originalbeschreibung: \u00fcber \u201eBilder & Texte laden\u201c erg\u00e4nzen oder Originalseite \u00f6ffnen.';c.hint.hidden=Boolean(c.item.description);}
function createNavigation(){
 $('categories').replaceChildren();navs.clear();
 for(const cat of [...guide.categories,{id:'all',title:'Alle Listen',icon:'all',count:guide.items.length}]){
  const b=mk('button','category-button'+(cat.id==='all'?' all-button':''));b.type='button';b.dataset.category=cat.id;const i=mk('span','cat-icon');i.append(icon(cat.icon));const counter=mk('b','','0 / '+cat.count);b.append(i,mk('span','',cat.title),counter);b.onclick=()=>changeCategory(cat.id);$('categories').append(b);navs.set(cat.id,{node:b,counter});
 }
 $('html-category').replaceChildren();for(const c of guide.categories){const o=mk('option','',c.title);o.value=c.id;$('html-category').append(o);}
}
function selectedItems(){return active==='all'?guide.items:guide.items.filter(i=>i.category===active);}
function changeCategory(id,updateHash=true){
 if(!cats.has(id)&&id!=='all')id='herzen';active=id;if(updateHash){try{history.replaceState(null,'','#'+id);}catch{/* Optional URL state may be disabled by a browser. */}}
 const cat=cats.get(id);$('category-title').textContent=cat?cat.title:'Alle Checklisten';$('category-intro').textContent=cat?cat.intro:'Alle zehn Bereiche, zusammen an einem Ort. Jede Markierung bleibt ihrer Checkliste zugeordnet.';
 $('category-eyebrow').textContent=cat?'DEIN ABENTEUER \u00b7 '+String(guide.categories.indexOf(cat)+1).padStart(2,'0')+' / 10':'DEINE GESAMTE SAMMLUNG';
 $('source-link').href=cat?cat.source:'https://zeldachronicles.de/spiele/oot/';$('source-link').textContent=cat?'Originalseite \u2197':'Zelda Chronicles \u2197';
 for(const [key,n] of navs){n.node.classList.toggle('active',key===id);n.node.setAttribute('aria-current',key===id?'page':'false');}
 $('region').replaceChildren();const all=mk('option','','Alle Gebiete');all.value='all';$('region').append(all);
 for(const r of [...new Set(selectedItems().map(i=>i.region))]){const o=mk('option','',r);o.value=r;$('region').append(o);}
 if(cat)$('html-category').value=id;$('reset-category').disabled=id==='all';renderCounters();filterCards();updateMedia();
}
function renderCounters(){
 if(!guide)return;const counts=new Map(guide.categories.map(c=>[c.id,0]));for(const id of checked){const c=id.split(':')[0];counts.set(c,(counts.get(c)||0)+1);}
 $('global-done').textContent=checked.size;$('global-total').textContent=guide.items.length;$('global-percent').textContent=Math.round(100*checked.size/guide.items.length)+' %';$('global-progress').max=guide.items.length;$('global-progress').value=checked.size;
 $('complete-cats').textContent=guide.categories.filter(c=>counts.get(c.id)===c.count).length+' von 10 Bereichen abgeschlossen';
 for(const [id,n] of navs){const total=id==='all'?guide.items.length:cats.get(id).count,done=id==='all'?checked.size:counts.get(id);n.counter.textContent=done+' / '+total;n.node.classList.toggle('complete',done===total);}
 const total=selectedItems().length,done=active==='all'?checked.size:counts.get(active);$('category-count').textContent=done+' / '+total;$('category-progress').max=total;$('category-progress').value=done;$('count-all').textContent=total;$('count-open').textContent=total-done;$('count-done').textContent=done;
}
function filterCards(){
 if(!guide)return;const q=fold($('search').value.trim()),region=$('region').value,age=$('age').value;let visible=0;
 for(const [id,c] of cards){const i=c.item;const show=(active==='all'||i.category===active)&&(statusFilter==='all'||(statusFilter==='done')===checked.has(id))&&(region==='all'||i.region===region)&&(age==='all'||i.age.includes(age))&&(!q||fold([i.title,i.region,i.hint,i.description,i.required,state.notes[id],cats.get(i.category).title].join(' ')).includes(q));c.node.hidden=!show;if(show)visible++;}
 $('visible-info').textContent=visible+' '+(visible===1?'Eintrag':'Eintr\u00e4ge');$('empty').hidden=visible>0;$('clear-filters').hidden=!q&&region==='all'&&age==='all'&&statusFilter==='all';
 for(const b of document.querySelectorAll('[data-status]')){b.classList.toggle('active',b.dataset.status===statusFilter);b.setAttribute('aria-pressed',String(b.dataset.status===statusFilter));}
}
function clearFilters(){statusFilter='all';$('search').value='';$('age').value='all';$('region').value='all';filterCards();}
async function reloadGuide(){
 const g=await api('guide');guide=g;lastRevision=g.revision;cats=new Map(g.categories.map(c=>[c.id,c]));byId=new Map(g.items.map(i=>[i.id,i]));
 if(!cards.size){createNavigation();const fragment=document.createDocumentFragment();for(const item of guide.items){const c=makeCard(item);cards.set(item.id,c);fragment.append(c.node);}$('entries').append(fragment);}
 else for(const item of guide.items){const c=cards.get(item.id);c.item=item;updateCardText(c);refreshPicture(c);}
 if(galleryItem&&$('lightbox').open){galleryItem=byId.get(galleryItem.id);showGallery();}filterCards();
}
function updateMedia(){
 if(!guide)return;const subset=selectedItems(),keys=new Set(subset.flatMap(i=>i.pictures.map(p=>p.key))),cached=new Set(media?media.cached_keys:guide.items.flatMap(i=>i.pictures.filter(p=>p.cached).map(p=>p.key)));
 const count=[...keys].filter(k=>cached.has(k)).length,loading=Boolean(media&&media.refreshing),error=media&&media.error;
 $('media-status').textContent=loading?media.stage:count===keys.size?'Alle '+count+' Bilder dieses Bereichs offline gespeichert.':count+' / '+keys.size+' Bilder dieses Bereichs offline. '+(guide.network?'Fehlende Bilder werden online angezeigt, soweit erreichbar.':'Zum Nachladen wird eine Internetverbindung ben\u00f6tigt.');
 $('media-bar').classList.toggle('loading',loading);$('media-bar').classList.toggle('warn',Boolean(error));$('download-current').disabled=loading||closed;$('download-all').disabled=loading||closed;
 $('cache-status').textContent=media?(media.cached_images+' / '+media.total_images+' Originalbilder lokal gespeichert.'+(error?' '+error:'')):'Bilderstatus wird gepr\u00fcft.';
 $('download-progress').hidden=!loading;$('download-progress').max=Math.max(1,media?media.total:1);$('download-progress').value=media?media.done:0;
 $('source-status-list').replaceChildren();for(const cat of guide.categories){const row=mk('div','source-status-row'),a=mk('a','',cat.title);a.href=cat.source;a.target='_blank';a.rel='noopener noreferrer';const g=(media?media.guides:guide.guides)[cat.id];const s=mk('span',g.loaded?'':'missing',g.loaded?'Beschreibung gespeichert':g.error?'Noch nicht geladen':'Beim ersten Laden');s.title=g.error||'';row.append(a,s);$('source-status-list').append(row);}
}
async function poll(){
 if(pollBusy||closed||!guide)return;pollBusy=true;
 try{media=await api('status');const networkChanged=guide.network!==media.network;guide.network=media.network;const keys=new Set(media.cached_keys);for(const i of guide.items){for(const p of i.pictures)p.cached=keys.has(p.key);refreshPicture(cards.get(i.id),networkChanged);}
  if(lastRevision!==media.revision)await reloadGuide();updateMedia();
 }catch(e){$('media-status').textContent=e.message;}finally{pollBusy=false;}
}
async function refresh(category){try{await api('refresh',{category});guide.network=true;tell('Bilder und Beschreibungen werden geladen. Du kannst weiter abhaken.');await poll();}catch(e){tell(e.message);}}
function openGallery(id,index){galleryItem=byId.get(id);galleryIndex=index;$('lightbox').showModal();showGallery();}
function showGallery(){
 const i=galleryItem;if(!i)return;galleryIndex=Math.min(Math.max(0,galleryIndex),i.pictures.length-1);const p=i.pictures[galleryIndex];$('lightbox-title').textContent=i.title;$('lightbox-category').textContent=cats.get(i.category).title+' \u00b7 '+i.region;$('gallery-counter').textContent=(galleryIndex+1)+' / '+i.pictures.length;
 $('gallery-prev').disabled=i.pictures.length<2;$('gallery-next').disabled=i.pictures.length<2;$('original-picture').href=p.url;$('lightbox-error').hidden=true;
 pictureTo($('lightbox-image'),p,ok=>{$('lightbox-error').hidden=ok;});$('lightbox-image').alt=i.title+' \u2013 Bild '+(galleryIndex+1);
 $('gallery-strip').replaceChildren();i.pictures.forEach((pic,j)=>{const b=mk('button',j===galleryIndex?'active':'',String(j+1));b.setAttribute('aria-label','Bild '+(j+1));b.setAttribute('aria-pressed',String(j===galleryIndex));b.onclick=()=>{galleryIndex=j;showGallery();};$('gallery-strip').append(b);});
}
function galleryStep(n){if(galleryItem){galleryIndex=(galleryIndex+n+galleryItem.pictures.length)%galleryItem.pictures.length;showGallery();}}
async function protectedAction(fn){if(busy||closed)return;busy=true;document.body.setAttribute('aria-busy','true');try{await waitSaved();await fn();}catch(e){tell(e.message);}finally{busy=false;document.body.removeAttribute('aria-busy');}}
function exportState(){const backup={app:'oot-sammel-checklisten',version:2,checked:[...checked].sort(),notes:{...state.notes},updated:new Date().toISOString()};const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));const a=mk('a');a.href=url;a.download='oot-sammelfortschritt-'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);tell('Sicherungsdatei erstellt.');}
function bind(){
 $('settings-open').onclick=()=>{$('settings').showModal();poll();};for(const b of document.querySelectorAll('.close-dialog'))b.onclick=()=>b.closest('dialog').close();
 $('search').oninput=filterCards;$('region').onchange=filterCards;$('age').onchange=filterCards;$('clear-filters').onclick=clearFilters;$('empty-reset').onclick=clearFilters;
 for(const b of document.querySelectorAll('[data-status]'))b.onclick=()=>{statusFilter=b.dataset.status;filterCards();};
 $('retry-save').onclick=()=>{saveFailure='';drain();};$('toast-undo').onclick=()=>{const f=undoAction;undoAction=null;$('toast').hidden=true;if(f)f();};
 $('download-current').onclick=()=>refresh(active);$('download-all').onclick=()=>refresh('all');$('gallery-prev').onclick=()=>galleryStep(-1);$('gallery-next').onclick=()=>galleryStep(1);
 $('export').onclick=exportState;$('import').onclick=()=>{$('backup-file').value='';$('backup-file').click();};
 $('backup-file').onchange=async()=>{const f=$('backup-file').files[0];if(!f)return;try{if(f.size>8*1024*1024)throw new Error('Die Datei ist zu gro\u00df.');const raw=JSON.parse(await f.text());const old=raw.app==='oot-herzteil-checkliste'&&raw.version===1;
  if(await confirmAction('Sicherung laden?',old?'Diese alte Sicherung ersetzt nur die Herzteil-H\u00e4kchen und Herzteil-Notizen. Die anderen neun Bereiche bleiben unver\u00e4ndert.':'Diese Sicherung ersetzt alle H\u00e4kchen und Notizen. Dein bisheriger Stand wird zuvor automatisch gesichert.','Sicherung laden'))await protectedAction(async()=>{const r=await api('import',{state:raw});generation++;applyState(r.state);tell('Sicherung geladen.');});
 }catch(e){tell(e instanceof SyntaxError?'Keine g\u00fcltige JSON-Sicherung.':e.message);}};
 $('import-html').onclick=()=>{$('html-file').value='';$('html-file').click();};
 $('html-file').onchange=async()=>{const f=$('html-file').files[0];if(!f)return;try{if(f.size>6*1024*1024)throw new Error('HTML-Datei ist zu gro\u00df.');const data=await f.arrayBuffer();let html;try{html=new TextDecoder('utf-8',{fatal:true}).decode(data);}catch{html=new TextDecoder('windows-1252').decode(data);}await api('import-guide',{category:$('html-category').value,html});await reloadGuide();await poll();tell('Originalbeschreibung importiert. H\u00e4kchen bleiben erhalten.');}catch(e){tell(e.message);}};
 async function reset(category){const name=category==='all'?'allen Bereichen':cats.get(category).title;if(await confirmAction('H\u00e4kchen zur\u00fccksetzen?','Alle H\u00e4kchen in '+name+' werden entfernt. Notizen bleiben erhalten. Eine Sicherung wird automatisch erstellt.','Zur\u00fccksetzen'))await protectedAction(async()=>{const r=await api('reset',{category});generation++;applyState(r.state);tell('H\u00e4kchen zur\u00fcckgesetzt.');});}
 $('reset-category').onclick=()=>reset(active);$('reset-all').onclick=()=>reset('all');
 $('shutdown').onclick=async()=>{if(!await confirmAction('App beenden?','Dein Fortschritt wird gespeichert und die lokale App beendet. Mit STARTEN.sh kannst du sie wieder \u00f6ffnen.','Speichern & beenden'))return;await protectedAction(async()=>{await api('shutdown',{});closed=true;clearInterval(pollTimer);clearInterval(stateTimer);$('settings').close();$('startup-warning').textContent='Die App wurde beendet. Du kannst dieses Fenster schlie\u00dfen. Zum Weiterf\u00fchren bitte STARTEN.sh starten.';$('startup-warning').hidden=false;for(const c of cards.values()){c.check.disabled=true;c.note.disabled=true;}$('shutdown').disabled=true;$('import').disabled=true;$('import-html').disabled=true;$('reset-all').disabled=true;$('reset-category').disabled=true;saveIndicator();updateMedia();});};
 $('back-top').onclick=e=>{e.preventDefault();window.scrollTo({top:0,behavior:'smooth'});};window.addEventListener('hashchange',()=>changeCategory(location.hash.slice(1),false));
 document.addEventListener('keydown',e=>{if($('lightbox').open){if(e.key==='ArrowRight'){e.preventDefault();galleryStep(1);}if(e.key==='ArrowLeft'){e.preventDefault();galleryStep(-1);}return;}if(e.key==='/'&&!e.target.closest('input,textarea,select')&&!document.querySelector('dialog[open]')){e.preventDefault();$('search').focus();}});
 window.addEventListener('beforeunload',e=>{if(saving||queue.length||notesTimers.size){flushNotes();e.preventDefault();e.returnValue='';}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&!closed&&notesTimers.size)flushNotes();});
}
async function init(){
 try{const s=await api('state');await reloadGuide();applyState(s.state);$('save-path').textContent=s.path;if(s.warning){$('startup-warning').textContent=s.warning;$('startup-warning').hidden=false;}bind();changeCategory(location.hash.slice(1)||'herzen');saveIndicator();await poll();
  pollTimer=setInterval(poll,3500);stateTimer=setInterval(async()=>{if(closed||busy||saving||queue.length||notesTimers.size||document.activeElement.matches('textarea'))return;const before=generation;try{const r=await api('state');if(before===generation&&!busy&&!saving&&!queue.length&&!notesTimers.size&&r.state.updated!==state.updated)applyState(r.state);}catch{}},10000);
 }catch(e){$('startup-warning').hidden=false;$('startup-warning').classList.add('error');$('startup-warning').textContent=e.message;$('category-intro').textContent='Bitte das vollst\u00e4ndige Archiv entpacken und STARTEN.sh ausf\u00fchren.';}
}
init();
