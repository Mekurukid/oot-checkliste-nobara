# OoT Sammel-Checklisten 2.7.0 – Nobara Edition

## Highlights

- 224 abhakbare Einträge in 10 Kategorien
- genaue Fundorte, Beschreibungen und Voraussetzungen
- 100 Goldene Skulltulas
- komplette Herzteil-, Masken-, Tausch-, Flaschen-, Wundererbsen- und Nachtschwärmer-Listen
- überarbeitete Kategorie Ausrüstung & Upgrades
- lokale Speicherung, Notizen und Sicherungen
- Nobara-optimierter Installer und Start
- keine zusätzlichen Python-Pakete nötig

## Installation auf Nobara

```bash
cd ~/Downloads
sh OoT-Nobara-Installieren-v2.7.run
```

Nicht mit `sudo` starten.

## Update

```bash
sh OoT-Nobara-Installieren-v2.7.run --restart
```

Vor einem Update offene Notizen speichern. Bestehende Häkchen und Fortschritte bleiben erhalten.
