# Sicherheit

Die App bindet ihren lokalen Server ausschließlich an `127.0.0.1` und verwendet einen zufälligen Sitzungspfad.

Bitte keine Sicherheitslücken öffentlich mit sensiblen Details posten. Für ein privates Repository kann zunächst ein privater Issue-/Kontaktweg verwendet werden.

Die App benötigt keine Root-Rechte und soll nicht mit `sudo` gestartet werden.
