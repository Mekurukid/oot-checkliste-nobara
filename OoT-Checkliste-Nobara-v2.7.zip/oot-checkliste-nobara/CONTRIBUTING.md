# Mitmachen

Beiträge sind willkommen.

## Lokale Entwicklung

```bash
git clone <REPO-URL>
cd oot-checkliste-nobara
python3 -m unittest discover -s tests -v
sh STARTEN.sh --no-download
```

## Pull Requests

Bitte:

1. Änderungen klein und nachvollziehbar halten.
2. Bei Änderungen an `catalog.json` Fundort und Voraussetzung prüfen.
3. Keine fremden Bilder, PDFs oder vollständigen Guide-Kopien ohne passende Rechte ins Repository aufnehmen.
4. Tests ausführen.
5. Bei sichtbaren Änderungen den Changelog ergänzen.

## Fehlerberichte

Für Startprobleme kann `sh DIAGNOSE.sh` verwendet werden. Diagnose-Dateien vor dem Hochladen bitte selbst kontrollieren.
