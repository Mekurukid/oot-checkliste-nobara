# Repository auf GitHub hochladen

## Variante A – GitHub-Webseite

1. Auf GitHub **New repository** erstellen.
2. Repository z. B. `oot-checkliste-nobara` nennen.
3. Beim Erstellen **kein zusätzliches README / .gitignore / LICENSE** erzeugen, weil diese Dateien bereits enthalten sind.
4. Danach **uploading an existing file** wählen.
5. Den Inhalt dieses Ordners hochladen.
6. Commit-Nachricht z. B. `Initial release 2.7.0`.

## Variante B – Terminal

Im entpackten Projektordner:

```bash
git init
git add .
git commit -m "Initial release 2.7.0"
git branch -M main
git remote add origin https://github.com/DEIN-NAME/oot-checkliste-nobara.git
git push -u origin main
```

## Release 2.7.0 anlegen

1. GitHub → **Releases** → **Draft a new release**.
2. Tag: `v2.7.0`
3. Titel: `OoT Sammel-Checklisten 2.7.0 – Nobara Edition`
4. Als Release-Dateien hochladen:
   - `OoT-Nobara-Installieren-v2.7.run`
   - `OoT-Checkliste-Nobara-v2.7.zip`
5. Text aus `RELEASE-NOTES-v2.7.md` verwenden.
