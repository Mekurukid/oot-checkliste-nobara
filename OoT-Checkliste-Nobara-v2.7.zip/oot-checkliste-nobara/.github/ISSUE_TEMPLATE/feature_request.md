---
name: Verbesserung vorschlagen
about: Idee für die Checkliste
title: "[Feature] "
labels: enhancement
---

**Idee:**

**Warum wäre das hilfreich?**

**Optional: Beispiel/Mockup:**
