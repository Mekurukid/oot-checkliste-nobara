---
name: Fehler melden
about: Start-, Anzeige- oder Speicherfehler melden
title: "[Bug] "
labels: bug
---

**Nobara/Linux-Version:**

**Desktop:** KDE / GNOME / anderer

**Python-Version:**

**Was ist passiert?**

**Was sollte passieren?**

**Schritte zum Nachstellen:**

**Fehlermeldung/Diagnose:**
